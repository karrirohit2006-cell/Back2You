import React from 'react';
import { SimulationProvider, useSimulation } from './context/SimulationContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { AISystemDetailsModal } from './components/common/AISystemDetailsModal';

// The 5 Simplified Core Pages
import { DashboardSimplePage } from './pages/DashboardSimplePage';
import { MyFieldSimplePage } from './pages/MyFieldSimplePage';
import { IrrigationPlannerSimplePage } from './pages/IrrigationPlannerSimplePage';
import { AIAssistantSimplePage } from './pages/AIAssistantSimplePage';
import { SettingsSimplePage } from './pages/SettingsSimplePage';

const AppContent: React.FC = () => {
  const { activeTab } = useSimulation();

  const renderActivePage = () => {
    switch (activeTab) {
      case 'dashboard':
      case 'overview':
        return <DashboardSimplePage />;

      case 'my-field':
      case 'field-management':
      case 'field-state':
      case 'simulator':
        return <MyFieldSimplePage />;

      case 'planner':
      case 'schedule-planner':
      case 'calculator':
      case 'search':
      case 'knowledge-engine':
      case 'agents':
      case 'edge-iot':
      case 'analytics-reports':
      case 'analytics':
        return <IrrigationPlannerSimplePage />;

      case 'assistant':
        return <AIAssistantSimplePage />;

      case 'settings':
        return <SettingsSimplePage />;

      default:
        return <DashboardSimplePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 antialiased selection:bg-emerald-500 selection:text-white">
      {/* Top Header */}
      <Header />

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {renderActivePage()}
        </main>
      </div>

      {/* Comprehensive 6-Concept Evaluation & Viva Modal */}
      <AISystemDetailsModal />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <SimulationProvider>
      <AppContent />
    </SimulationProvider>
  );
};

export default App;
