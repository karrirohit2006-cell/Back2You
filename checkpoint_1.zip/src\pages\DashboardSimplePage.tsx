import React, { useState, useEffect } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { api, FieldDto, WeatherResponseDto, IrrigationRequirementDto } from '../services/api';
import {
  Droplet,
  Calendar,
  TrendingDown,
  ArrowRight,
  Sun,
  CloudRain,
  CloudSun,
  Layers,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Sparkles,
  Info
} from 'lucide-react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';

export const DashboardSimplePage: React.FC = () => {
  const { setActiveTab, setIsAIDetailsOpen, timeSeries } = useSimulation();

  const [fields, setFields] = useState<FieldDto[]>([]);
  const [selectedFieldId, setSelectedFieldId] = useState<string>('field-01');
  const [currentField, setCurrentField] = useState<FieldDto | null>(null);
  const [weather, setWeather] = useState<WeatherResponseDto | null>(null);
  const [requirement, setRequirement] = useState<IrrigationRequirementDto | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const fList = await api.getFields();
        setFields(fList);
        if (fList.length > 0) {
          const defaultField = fList.find((f) => f.id === selectedFieldId) || fList[0];
          setCurrentField(defaultField);

          const [wRes, reqRes] = await Promise.all([
            api.getForecast(defaultField.id).catch(() => null),
            api.getRequirement(defaultField.id).catch(() => null)
          ]);
          setWeather(wRes);
          setRequirement(reqRes);
        }
      } catch (err) {
        console.warn('Dashboard data load error:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [selectedFieldId]);

  const handleSelectField = (fid: string) => {
    setSelectedFieldId(fid);
  };

  const moisturePct = currentField?.volumetric_moisture ?? 24;
  const fcPct = currentField?.field_capacity ?? 32;
  const pwpPct = currentField?.wilting_point ?? 14;

  const isMoistureOptimal = moisturePct >= 20;
  const waterNeededLitres = requirement?.irrigation_water_volume_liters ?? 250000;
  const waterNeededMm = requirement?.gross_irrigation_depth_mm ?? 48;

  // Simple 7-day forecast cards
  const sevenDays = [
    { day: 'Today', temp: 28, rain: 0, status: 'No Watering' },
    { day: 'Tomorrow', temp: 29, rain: 0, status: 'Water 35mm' },
    { day: 'Wed', temp: 27, rain: 0, status: 'No Watering' },
    { day: 'Thu', temp: 24, rain: 14, status: 'Rain Expected' },
    { day: 'Fri', temp: 25, rain: 2, status: 'No Watering' },
    { day: 'Sat', temp: 28, rain: 0, status: 'Water 12mm' },
    { day: 'Sun', temp: 29, rain: 0, status: 'No Watering' },
  ];

  const [chartView, setChartView] = useState<'7DAY' | '24HR'>('7DAY');

  // Compute dynamic 7-day soil moisture progression based on selected field
  const sevenDayChartData = React.useMemo(() => {
    const baseM = currentField?.volumetric_moisture ?? 24.0;
    const fc = currentField?.field_capacity ?? 32.0;
    const pwp = currentField?.wilting_point ?? 14.0;

    return [
      { label: 'Today', soilMoisture: baseM, moisture: baseM, note: 'Current Telemetry' },
      { label: 'Tomorrow', soilMoisture: Math.min(fc, Number((baseM + 7.5).toFixed(1))), moisture: Math.min(fc, Number((baseM + 7.5).toFixed(1))), note: 'After 35mm Watering' },
      { label: 'Wed', soilMoisture: Math.max(pwp, Number((baseM + 5.2).toFixed(1))), moisture: Math.max(pwp, Number((baseM + 5.2).toFixed(1))), note: 'Evapotranspiration' },
      { label: 'Thu', soilMoisture: Math.min(fc, Number((baseM + 6.8).toFixed(1))), moisture: Math.min(fc, Number((baseM + 6.8).toFixed(1))), note: '14mm Rain Forecast' },
      { label: 'Fri', soilMoisture: Math.max(pwp, Number((baseM + 4.5).toFixed(1))), moisture: Math.max(pwp, Number((baseM + 4.5).toFixed(1))), note: 'Evapotranspiration' },
      { label: 'Sat', soilMoisture: Math.min(fc, Number((baseM + 7.0).toFixed(1))), moisture: Math.min(fc, Number((baseM + 7.0).toFixed(1))), note: 'After 12mm Watering' },
      { label: 'Sun', soilMoisture: Math.max(pwp, Number((baseM + 5.0).toFixed(1))), moisture: Math.max(pwp, Number((baseM + 5.0).toFixed(1))), note: 'Optimal Buffer' },
    ];
  }, [currentField]);

  // Compute dynamic 24-hour hourly telemetry
  const hourlyChartData = React.useMemo(() => {
    const baseM = currentField?.volumetric_moisture ?? 24.0;
    const hours = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22];
    return hours.map((h) => {
      const daylightDecay = h >= 10 && h <= 16 ? 0.9 : 0.2;
      const m = Number((baseM - (h / 24) * daylightDecay).toFixed(1));
      return {
        label: `${h.toString().padStart(2, '0')}:00`,
        soilMoisture: m,
        moisture: m,
        note: `Hour ${h}:00 Sensor Reading`
      };
    });
  }, [currentField]);

  const activeChartData = chartView === '7DAY' ? sevenDayChartData : hourlyChartData;

  return (
    <div className="space-y-6 animate-in fade-in duration-200 max-w-6xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
              Smart Irrigation Planner
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs text-slate-500 font-medium">Automatic Field Management</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight mt-1.5">
            Welcome to AgroSmart
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Real-time soil moisture monitoring and AI-guided water recommendations for your crops.
          </p>
        </div>

        {/* Field Selector */}
        <div className="flex items-center space-x-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
          <Layers className="w-4 h-4 text-emerald-700 shrink-0" />
          <div className="text-left">
            <label className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">
              Selected Field
            </label>
            <select
              value={selectedFieldId}
              onChange={(e) => handleSelectField(e.target.value)}
              className="bg-transparent text-sm font-bold text-slate-800 focus:outline-none cursor-pointer pr-4"
            >
              {fields.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.crop_type})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Field Quick Overview Pill */}
      {currentField && (
        <div className="bg-emerald-50/70 border border-emerald-100 rounded-xl px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-900">
          <div className="flex items-center space-x-4">
            <span><strong>Crop:</strong> {currentField.crop_type} ({currentField.growth_stage})</span>
            <span><strong>Area:</strong> {currentField.area_ha} hectares</span>
            <span><strong>Soil Type:</strong> {currentField.soil_type}</span>
          </div>
          <div className="flex items-center space-x-2 text-emerald-700">
            <Sun className="w-4 h-4" />
            <span>Weather: <strong>{currentField.temperature_c}°C</strong>, Sunny ({currentField.relative_humidity}% Humidity)</span>
          </div>
        </div>
      )}

      {/* 4 MAIN METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Soil Moisture */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Soil Moisture</span>
            <span className={`p-2 rounded-xl ${isMoistureOptimal ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
              <Droplet className="w-4 h-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900 font-mono">
              {moisturePct}%
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Target level: {fcPct}% • Wilting point: {pwpPct}%
            </p>
          </div>
          <div className="flex items-center space-x-1.5 text-[11px] font-medium text-emerald-700">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>{isMoistureOptimal ? 'Optimal buffer zone' : 'Approaching refill threshold'}</span>
          </div>
        </div>

        {/* Metric 2: Water Required */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Water Required</span>
            <span className="p-2 rounded-xl bg-blue-50 text-blue-700">
              <Droplet className="w-4 h-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900 font-mono">
              {waterNeededLitres > 0 ? `${(waterNeededLitres / 1000).toLocaleString()} m³` : '0 Litres'}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {waterNeededMm > 0 ? `${waterNeededMm} mm application depth` : 'Soil moisture sufficient'}
            </p>
          </div>
          <div className="text-[11px] font-medium text-slate-500">
            Across {currentField?.area_ha || 2.5} hectares
          </div>
        </div>

        {/* Metric 3: Next Irrigation */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Next Irrigation</span>
            <span className="p-2 rounded-xl bg-purple-50 text-purple-700">
              <Calendar className="w-4 h-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900">
              Tomorrow
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Recommended window: 06:00 AM (Cool hours)
            </p>
          </div>
          <div className="text-[11px] font-medium text-purple-700">
            Duration: ~3.5 hours at pump capacity
          </div>
        </div>

        {/* Metric 4: Water Saved */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Water Saved</span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
              <TrendingDown className="w-4 h-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-emerald-700 font-mono">
              32.9%
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Compared to standard timer schedule
            </p>
          </div>
          <div className="text-[11px] font-medium text-emerald-700">
            575 m³ saved this period
          </div>
        </div>
      </div>

      {/* PRIMARY ACTION BUTTON */}
      <div className="bg-gradient-to-r from-emerald-700 to-green-800 rounded-2xl p-6 text-white shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <h2 className="text-lg font-bold">Ready to generate your optimized schedule?</h2>
          <p className="text-xs text-emerald-100 max-w-xl">
            The AI search algorithm evaluates soil moisture, rainfall forecasts, and crop growth to create a water-conserving plan.
          </p>
        </div>
        <button
          onClick={() => setActiveTab('planner')}
          className="px-6 py-3 rounded-xl bg-white text-emerald-900 hover:bg-emerald-50 text-sm font-bold shadow-lg transition-all flex items-center space-x-2 shrink-0"
        >
          <span>Plan Irrigation</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* WHY IS THIS RECOMMENDATION MADE? */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm space-y-3">
        <div className="flex items-center space-x-2">
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <Info className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">
            Why is this recommendation made?
          </h3>
        </div>

        <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200">
          "Your soil moisture is currently at <strong>{moisturePct}%</strong>, which is within the safe buffer zone for <strong>{currentField?.crop_type}</strong>. The system has calculated expected daily water loss and checked the 7-day weather forecast. Because rainfall of 14 mm is expected on Thursday, irrigation is scheduled for tomorrow to maintain root-zone health without wasting water before the storm."
        </p>

        <div className="flex items-center justify-between pt-1 text-xs">
          <span className="text-slate-500">Calculated using scientifically verified crop water balance formulas (FAO-56 standard).</span>
          <button
            onClick={() => setIsAIDetailsOpen(true)}
            className="text-emerald-700 hover:text-emerald-800 font-semibold underline flex items-center space-x-1"
          >
            <span>Inspect AI System Details (Evaluation)</span>
          </button>
        </div>
      </div>

      {/* 7-DAY IRRIGATION OVERVIEW */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">7-Day Irrigation Schedule Overview</h3>
            <p className="text-xs text-slate-500">Daily forecast and recommended watering actions</p>
          </div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
            AI Schedule Search Active
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {sevenDays.map((d, i) => (
            <div
              key={i}
              className={`p-3.5 rounded-xl border text-center flex flex-col justify-between space-y-2 transition-all ${
                d.status.includes('Water')
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950 font-medium shadow-sm'
                  : d.status.includes('Rain')
                  ? 'bg-blue-50/80 border-blue-200 text-blue-950 font-medium'
                  : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
            >
              <div className="text-xs font-bold text-slate-900">{d.day}</div>
              <div className="flex justify-center my-1 text-slate-600">
                {d.rain > 0 ? (
                  <CloudRain className="w-5 h-5 text-blue-600" />
                ) : (
                  <Sun className="w-5 h-5 text-amber-500" />
                )}
              </div>
              <div className="text-[11px] font-mono text-slate-600">
                {d.temp}°C {d.rain > 0 ? `• ${d.rain}mm rain` : ''}
              </div>
              <div
                className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                  d.status.includes('Water')
                    ? 'bg-emerald-600 text-white'
                    : d.status.includes('Rain')
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {d.status}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SOIL MOISTURE TREND CHART */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Soil Moisture Trend</h3>
            <p className="text-xs text-slate-500">Tracking moisture retention vs preferred crop limits</p>
          </div>

          <div className="flex items-center flex-wrap gap-2 text-xs">
            {/* View Switcher: 7-Day vs 24-Hour */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setChartView('7DAY')}
                className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                  chartView === '7DAY'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                7-Day Schedule
              </button>
              <button
                type="button"
                onClick={() => setChartView('24HR')}
                className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                  chartView === '24HR'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                24-Hour Telemetry
              </button>
            </div>

            <div className="hidden md:flex items-center space-x-3 pl-2">
              <span className="flex items-center space-x-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span>
                <span>Moisture %</span>
              </span>
              <span className="flex items-center space-x-1.5 text-emerald-600">
                <span className="w-2.5 h-1 border-t-2 border-dashed border-emerald-500 inline-block"></span>
                <span>Field Capacity ({fcPct}%)</span>
              </span>
              <span className="flex items-center space-x-1.5 text-rose-500">
                <span className="w-2.5 h-1 border-t-2 border-dashed border-rose-500 inline-block"></span>
                <span>Wilting Point ({pwpPct}%)</span>
              </span>
            </div>
          </div>
        </div>

        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={activeChartData} margin={{ top: 15, right: 15, left: -20, bottom: 5 }}>
              <defs>
                <linearGradient id="moistureGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#059669" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="label" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis
                domain={[Math.max(0, Math.floor(pwpPct - 5)), Math.ceil(fcPct + 6)]}
                stroke="#64748b"
                fontSize={11}
                unit="%"
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderRadius: '12px',
                  border: '1px solid #e2e8f0',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  fontSize: '12px'
                }}
                formatter={(value: any, _name: any, item: any) => [
                  `${Number(value).toFixed(1)}% (${item?.payload?.note || 'Soil Moisture'})`,
                  'Moisture Level'
                ]}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <ReferenceLine
                y={fcPct}
                stroke="#10b981"
                strokeDasharray="4 4"
                label={{ value: `Field Capacity: ${fcPct}%`, position: 'top', fill: '#059669', fontSize: 10 }}
              />
              <ReferenceLine
                y={pwpPct}
                stroke="#f43f5e"
                strokeDasharray="4 4"
                label={{ value: `Wilting Point: ${pwpPct}%`, position: 'bottom', fill: '#e11d48', fontSize: 10 }}
              />
              <Area
                type="monotone"
                dataKey="soilMoisture"
                stroke="#059669"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#moistureGradient)"
                dot={{ fill: '#059669', r: 4, strokeWidth: 2, stroke: '#ffffff' }}
                activeDot={{ r: 6, stroke: '#059669', strokeWidth: 2, fill: '#ffffff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
