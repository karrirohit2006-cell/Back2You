import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import {
  Droplets,
  Thermometer,
  CloudRain,
  Wind,
  Layers,
  Sprout,
  Clock,
  Sparkles,
  TrendingDown,
  Calendar,
  Waves,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  LineChart,
  Line,
} from 'recharts';

export const DashboardPage: React.FC = () => {
  const { fieldState, timeSeries, setActiveTab } = useSimulation();
  const { parameters, environment, soil, aiRecommendation, irrigationStatus } = fieldState;

  return (
    <div className="space-y-6">
      {/* Welcome & Overview Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 p-5 rounded-2xl border border-emerald-500/20">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              Field Telemetry Online
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Last updated: {fieldState.timestamp}
            </span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Agricultural Field Irrigation Command Center
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {parameters.fieldSize} Acres of {parameters.crop} ({parameters.growthStage} Stage) in {parameters.soilType} substrate
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <StatusBadge status={irrigationStatus} size="lg" />
          <button
            onClick={() => setActiveTab('simulator')}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center space-x-1"
          >
            <span>Configure Field</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Field & Environmental Parameters Grid */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
          1. Field & Environmental Telemetry
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          <MetricCard
            title="Soil Moisture"
            value={soil.currentMoisture}
            unit="%"
            subtitle={`FC: ${soil.fieldCapacity}%`}
            icon={Droplets}
            iconColor="text-emerald-400"
            highlight
          />
          <MetricCard
            title="Temperature"
            value={environment.temperature}
            unit="°C"
            subtitle={`RH: ${environment.humidity}%`}
            icon={Thermometer}
            iconColor="text-amber-400"
          />
          <MetricCard
            title="Humidity"
            value={environment.humidity}
            unit="%"
            subtitle="Relative Air"
            icon={Waves}
            iconColor="text-sky-400"
          />
          <MetricCard
            title="Rain Probability"
            value={environment.rainProbability}
            unit="%"
            subtitle={`${environment.rainfallAmount || 0} mm forecast`}
            icon={CloudRain}
            iconColor="text-cyan-400"
          />
          <MetricCard
            title="Crop"
            value={parameters.crop}
            subtitle={parameters.growthStage}
            icon={Sprout}
            iconColor="text-emerald-400"
          />
          <MetricCard
            title="Soil Type"
            value={parameters.soilType}
            subtitle={`WP: ${soil.wiltingPoint}%`}
            icon={Layers}
            iconColor="text-amber-300"
          />
          <MetricCard
            title="Wind Speed"
            value={environment.windSpeed}
            unit="km/h"
            subtitle="Aerodynamic loss"
            icon={Wind}
            iconColor="text-slate-400"
          />
          <MetricCard
            title="Field Area"
            value={parameters.fieldSize}
            unit="Acres"
            subtitle={parameters.irrigationMethod}
            icon={Calendar}
            iconColor="text-teal-400"
          />
        </div>
      </div>

      {/* Irrigation Status & Cumulative Accounting */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
          2. Irrigation Accounting & Hydraulic Status
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="agri-card space-y-2">
            <span className="text-xs text-slate-400 font-medium">Recommended Water</span>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-bold text-white font-mono">
                {aiRecommendation.waterAmountLiters.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">Liters</span>
            </div>
            <div className="text-[11px] text-emerald-400 font-mono">
              Depth: {aiRecommendation.waterDepthMm} mm
            </div>
          </div>

          <div className="agri-card space-y-2">
            <span className="text-xs text-slate-400 font-medium">Application Duration</span>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-bold text-white font-mono">
                {aiRecommendation.durationMinutes}
              </span>
              <span className="text-xs text-slate-400">Minutes</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Method: {parameters.irrigationMethod}
            </div>
          </div>

          <div className="agri-card space-y-2">
            <span className="text-xs text-slate-400 font-medium">Optimal Window</span>
            <div className="flex items-baseline space-x-1">
              <span className="text-lg font-bold text-emerald-300">
                {aiRecommendation.optimalTime}
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              Deficit SMD: {fieldState.smd} mm
            </div>
          </div>

          <div className="agri-card space-y-2">
            <span className="text-xs text-slate-400 font-medium">Cumulative Water Used</span>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-bold text-white font-mono">
                {fieldState.cumulativeWaterUsedLiters.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">L</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Measured across season
            </div>
          </div>

          <div className="agri-card space-y-2 border-emerald-500/30 bg-emerald-950/10">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Water Conserved vs Fixed</span>
              <TrendingDown className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-bold text-emerald-400 font-mono">
                {fieldState.cumulativeWaterSavedLiters.toLocaleString()}
              </span>
              <span className="text-xs text-emerald-400">Liters</span>
            </div>
            <div className="text-[11px] text-emerald-400/80">
              ~38% water efficiency gain
            </div>
          </div>
        </div>
      </div>

      {/* AI Decision Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 rounded-2xl border border-emerald-500/30 p-5 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">
                AI Intelligence Recommendation & Rationale
              </h3>
              <p className="text-xs text-slate-400">
                Action: <span className="font-mono text-emerald-400 font-bold">{aiRecommendation.action}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Simulated Confidence:</span>
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold border border-emerald-500/40">
              {aiRecommendation.confidence}%
            </span>
          </div>
        </div>

        {/* Primary AI Recommendation Statement */}
        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800/80">
          <p className="text-sm text-slate-100 font-medium leading-relaxed">
            "{aiRecommendation.summary}"
          </p>
        </div>

        {/* Reasoning Steps & Agronomic Factors */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Reasoning Engine Steps:
            </h4>
            <div className="space-y-1.5 text-xs text-slate-300">
              {aiRecommendation.reasoning.map((reason, idx) => (
                <div key={idx} className="flex items-start space-x-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{reason}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2 bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 text-xs">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Agronomic Risk Analysis:
            </h4>
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Soil Water:</span>
                <span className="text-slate-200 font-mono">{aiRecommendation.keyFactors.soilStatus}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Atmosphere / Rain:</span>
                <span className="text-slate-200 font-mono">{aiRecommendation.keyFactors.weatherRisk}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Crop Health Stress:</span>
                <span className="text-amber-300 font-mono">{aiRecommendation.keyFactors.cropStressRisk}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Water Conservation:</span>
                <span className="text-emerald-400 font-mono">{aiRecommendation.keyFactors.conservationImpact}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Realistic Interactive Simulation Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Soil Moisture & Crop Water Deficit Trajectory */}
        <div className="agri-card space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Soil Moisture Dynamics (24-Hour Timeline)
              </h3>
              <p className="text-[11px] text-slate-400">
                Hourly volumetric water content (%) vs Field Capacity & Wilting Point
              </p>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
              FC: {soil.fieldCapacity}% | WP: {soil.wiltingPoint}%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timeSeries} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="moistureGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="hourLabel" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis domain={[soil.wiltingPoint - 4, soil.fieldCapacity + 6]} stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                />
                <Area
                  type="monotone"
                  dataKey="soilMoisture"
                  name="Soil Moisture (%)"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#moistureGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Temperature & Diurnal Rain Probability */}
        <div className="agri-card space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Temperature & Rainfall Forecast Trend
              </h3>
              <p className="text-[11px] text-slate-400">
                Ambient Temperature (°C) and Precipitation Probability (%)
              </p>
            </div>
            <span className="text-[10px] font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20">
              Rain Chance: {environment.rainProbability}%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeSeries} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="hourLabel" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                />
                <Line
                  type="monotone"
                  dataKey="temperature"
                  name="Temperature (°C)"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="rainProbability"
                  name="Rain Probability (%)"
                  stroke="#38bdf8"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
